import express from 'express';
import cors from 'cors';

export class Server {
    private app = express();
    private readonly port: number;

    constructor(port: number) {
        this.port = port;
    }

    start() {
        this.app.use(cors());
        this.app.use(express.json());
        this.app.use(express.urlencoded({ extended: true }));

        // Temporal: mensaje cuando no hay rutas
        this.app.get('/', (req, res) => {
            res.send('API funcionando correctamente');
        });

        // this.app.get('/api/users', (req, res) => {
        //     res.json([
        //         { id: 1, name: 'Bryan', lastName: 'Aguirre', },
        //         { id: 2, name: 'Jhon', lastName: 'Doe', },
        //         { id: 3, name: 'William', lastName: 'Smith', },
        //     ])
        // })

        this.app.listen(this.port, () => {
            console.log(`Servidor runnig on port ${this.port}`);
        });
    }
}