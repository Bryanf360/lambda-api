import { prisma } from "../prisma/client";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

export class AuthService {

  async register(data: any) {

    const { names, lastnames, email, password } = data;

    const exists = await prisma.user.findUnique({
      where: { email }
    });

    if (exists) throw new Error("El email ya está registrado");

    const hashed = bcrypt.hashSync(password, 10);

    const user = await prisma.user.create({
      data: { names, lastnames, email, password: hashed }
    });

    const token = jwt.sign(
      { id: user.id },
      process.env.JWT_SECRET!,
      { expiresIn: "1d" }
    );

    return { user, token };
  }


  async login(data: any) {
    const { email, password } = data;

    const user = await prisma.user.findUnique({
      where: { email }
    });

    if (!user) throw new Error("Credenciales incorrectas");

    const match = bcrypt.compareSync(password, user.password);

    if (!match) throw new Error("Credenciales incorrectas");

    const token = jwt.sign(
      { id: user.id },
      process.env.JWT_SECRET!,
      { expiresIn: "1d" }
    );

    return { user, token };
  }
}